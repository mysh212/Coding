#ifndef FIELD_H
#define FIELD_H
#include"../../all.h"
#include"../misc/Character.h"
using namespace std;


class field {
    public:
    vector<vector<int>>f;
    vector<vector<Character>>v;
    Character player;
    int n,m;
    int x,y;

    static bool check(vector<vector<bool>>&f,int x,int y) {
        const int xx[] = {0,1,0,-1};
        const int yy[] = {1,0,-1,0};
        for(int i = 0;i<=3;i++) {
            int nx = x + xx[i];
            int ny = y + yy[i];


        }
    }

    field(int n,int m,int k):
        n(n), m(m), x(1), y(1), player('P',true,new NovicePlayer()), f({
        {1,1,1,1,1,1,1,1,1,1,1,1},
        {1,3,0,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,0,1},
        {1,0,0,0,0,0,0,0,0,0,0,1},
        {1,0,1,1,1,1,1,1,1,1,1,1},
        {1,0,0,0,0,0,0,0,0,0,0,1},
        {1,1,1,1,1,1,1,1,1,1,1,1}
        }), v(n,vector<Character>(m)) {
            while(k--) {
                int x = rand() % n;
                int y = rand() % m;

                while((f.at(x).at(y) == 1) || (v.at(x).at(y).type != '\0') || (x == this->x && y == this->y)) {
                    x = rand() % n;
                    y = rand() % m;
                }

                Character now;

                int t = rand() % 3;
                
                if(t == 0) now = Character('M',true,new GoblinMonster());
                if(t == 1) now = Character('M',true,new JWMonster());
                if(t == 2) now = Character('M',true,new ZombieMonster());

                v.at(x).at(y) = now;
                f.at(x).at(y) = 2;
            }
        };

    void print() {
        for(int i = 0;i<n;i++) {
            for(int j = 0;j<m;j++) {
                if(i == x && j == y) {
                    cout<<"P";
                }
                if(f.at(i).at(j) == 1) cout<<"#";
                if(f.at(i).at(j) == 2) cout<<(v.at(i).at(j).alive ? "M" : "X");
                if(f.at(i).at(j) == 0) cout<<"_";
                // if(f.at(i).at(j) == 3) cout<<"P";
            }
            cout<<"\n";
        }
    }

    void walk(int i) {
        const int xx[] = {0,1,0,-1};
        const int yy[] = {1,0,-1,0};

        int nx = x + xx[i];
        int ny = y + yy[i];

        if(nx < 0 || ny < 0 || nx >= n || ny >= m) return;
        if(f.at(nx).at(ny) == 2) {
            cout<<"Battle\n";
            Character *now[2];
            now[0] = &player;
            now[1] = &v.at(nx).at(ny);
            Battle tmp(1,1,now);

            if(!player.alive) cout<<"Player has no ability to fight.\n";
            exit(0);
        }
        if(f.at(nx).at(ny) != 0) return;

        // f.at(x).at(y) = 0;
        // f.at(nx).at(ny) = 1;
        x = nx,y = ny;
    }
};


#endif